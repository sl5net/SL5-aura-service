# Documentation

"""

# AUTOMATED ARCHIVE GENERATION

This archive was automatically created and updated by SL5 Aura.

TRIGGER:
Folders starting with "_" are monitored by SL5 Aura.
Any change to the content automatically triggers a re-zip process.

TECHNICAL NOTE:
You will find `__init__.py` `README_AUTOZIP.py` included.
You dont need them when you dont use Aura.

---
Generiert von SL5 Aura
The Architect's Solution for Offline Voice Control.
100% Privacy. 100% Offline.

"""
